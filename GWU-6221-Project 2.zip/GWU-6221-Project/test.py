#from urllib import request
from json import dumps

from flask import Flask, jsonify, request, session, current_app

from openaiService import generate_information_service, generate_subtopic_service, generate_more_subtopic_service, generate_summary_service
from databaseService import db, before_first_request_service, User, \
    gain_user_note_service, Note
from authentication import authenticate_user



app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://admin:password@database-1.ca8rfuzwlbnt.us-west-2.rds.amazonaws.com/openai'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['INITIALIZED'] = False
app.secret_key = '123456'

db.init_app(app)

@app.route("/")
def index():
    return "Hello, world!"

@app.route("/generate_information", methods=["GET", "POST"])
def generate_information():
    response_json = generate_information_service()
    with current_app.app_context():

        user = User.query.filter_by(username=session['username']).first()
        if not user:
            return jsonify({"message": "未找到用户。"}), 404

        user.user_information_history.append(response_json)


    return jsonify(response_json)

@app.route("/generate_subtopic", methods=["GET", "POST"])
def generate_more_subtopic():
    with current_app.app_context():

        user = User.query.filter_by(username=session['username']).first()

        if not user:
            return jsonify({"message": "未找到用户。"}), 404

        user.user_information_history.append(request.json.get("user_input"))

    response_json = generate_subtopic_service()
    return jsonify(response_json)



@app.route("/generate_more_subtopic", methods=["GET", "POST"])
def generate_subtopic():
    response_json = generate_more_subtopic_service()

    return jsonify(response_json)


@app.route("/generate_summary", methods=["GET"])
def generate_summary():

    with current_app.app_context():

        user = User.query.filter_by(username=session['username']).first()

        if not user:
            return jsonify({"message": "未找到用户。"}), 404

        information_history = user.user_information_history

        print("Generated information summary:", information_history)
        summary = "\n".join(str(info) for info in information_history)

        response_json = generate_summary_service(summary)
        print("Generated summary:", response_json)
        content_to_store = response_json['choices'][0]['message']['content']
        print("Summary content:", content_to_store)



        new_note = Note(content=content_to_store, author=user)

        try:
            user.user_information_history.clear()
            db.session.add(new_note)
            db.session.commit()

        except Exception as e:
            db.session.rollback()
        finally:
            # 关闭数据库会话
            db.session.close()

    return jsonify(response_json)

@app.route("/store_user_input", methods=["POST"])
def store_user_input():
    # 获取用户输入数据
    user_input = request.json.get("user_input")
    print("User Input:", user_input)

    # 在应用上下文中检索用户
    user = User.query.filter_by(username=session['username']).first()

    if not user:
        return jsonify({"message": "未找到用户。"}), 404


    content_str = dumps(user_input)
    new_note = Note(content=content_str, author=user)

    try:
        db.session.add(new_note)
        db.session.commit()
        return jsonify({"message": "用户输入保存成功"})
    except Exception as e:
        print(f"保存用户输入到数据库时出错：{e}")
        db.session.rollback()
        return jsonify({"message": "保存用户输入到数据库时出错"}), 500
    finally:
        db.session.close()



@app.before_request
def initialize_database_route():
    if not app.config['INITIALIZED']:
        before_first_request_service()
        app.config['INITIALIZED'] = True
        print("Database initialized successfully.")



@app.route("/gain_user_note", methods=["GET"])
def gain_user_note():
    user_name = session['username']
    user_notes = gain_user_note_service(user_name)
    if not user_notes:
        return jsonify({"message": "User not found."}), 404
    user_notes_dict_list = [{"id": note.id, "content": note.content} for note in user_notes]
    return jsonify({"user_notes": user_notes_dict_list})


def authenticate_user(username, password):
    user = User.query.filter_by(username=username).first()
    if user and user.password == password:
        return True
    else:
        return False


@app.route("/register", methods=["POST"])
def register_route():
    data = request.json
    username = data['username']
    password = data['password']
    name = data.get('name', '')

    existing_user = User.query.filter_by(username=username).first()
    if existing_user:
        return jsonify({"message": "Username already exists. Choose a different username."}), 400


    new_user = User(name=name, username=username, password=password)

    try:
        db.session.add(new_user)
        db.session.commit()
        return jsonify({"message": "Registration successful. You can now log in."})
    except Exception as e:
        print(f"Error registering user: {e}")
        db.session.rollback()
        return jsonify({"message": "Error registering user."}), 500
    finally:
        db.session.close()


@app.route("/login", methods=["POST"])
def login_route():
    data = request.json
    username = data['username']
    password = data['password']

    if authenticate_user(username, password):
        session['logged_in'] = True
        session['username'] = username

        return jsonify({"message": "Login successful"})
    else:
        return jsonify({"message": "Login failed"})

@app.route("/logout", methods=["GET"])
def logout_route():
    user_name = session.get('username')
    if user_name:
        user = User.query.filter_by(username=user_name).first()
        if user:
            user.user_information_history = []
    session.clear()

    return jsonify({"message": "Logout successful"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)


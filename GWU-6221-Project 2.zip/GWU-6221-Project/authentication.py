from flask import jsonify, request

from databaseService import User


def authenticate_user(username, password):
    user = User.query.filter_by(username=username).first()
    print("jhon")
    if user and user.password == password:
        return True
    else:
        return False



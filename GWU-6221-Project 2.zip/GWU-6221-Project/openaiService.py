from flask import Flask, request
import requests
import json
from databaseService import Note, db

def index():
    return "Hello, world!"


def generate_information_service():
    user_input = request.json.get("user_input")

    while True:
        if user_input == "quit":
            break

        else:
            related_information = f"generate related detail about {user_input} "

            response = requests.post(
                "https://api.openai.com/v1/chat/completions",
                headers={
                    "Content-Type": "application/json",
                    "Authorization": "Bearer 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",
                },
                json={

                    "model": "gpt-3.5-turbo-1106",
                    "temperature": 0.3,
                    "messages": [
                        {"role": "system", "content": "You are a helpful, professional information search expert."},
                        {"role": "user", "content": related_information},
                    ],
                },
            )
        response_json = json.loads(response.content)
        return response_json



def generate_subtopic_service():
    user_input = request.json.get("user_input")
    while True:
        if user_input == "quit":
            break
        else:
            print(user_input)

            related_topic = f"generate related topic about {user_input},  Each relevant topic should be separated by '\n'.. "
            response = requests.post(
                "https://api.openai.com/v1/chat/completions",
                headers={
                    "Content-Type": "application/json",
                    "Authorization": "Bearer ssk-WvLAvYrrJMnoeTSNJz2FT3BlbkFJF9u1SPiOfhpNRCZ77GkM",
                },
                json={
                    "model": "gpt-3.5-turbo-1106",
                    "temperature": 0.3,
                    "messages": [
                        {"role": "system", "content": "You are a helpful, professional information search expert."},
                        {"role": "user", "content": related_topic},
                    ],
                },
            )
        response_json = json.loads(response.content)
        return response_json


def generate_more_subtopic_service():
    user_input = request.json.get("user_input")
    while True:
        if user_input == "quit":
            break
        else:
            print(user_input)
            related_topic = f"generate more related topic about {user_input}, Each relevant topic should be separated by '\n'.."
            response = requests.post(
                "https://api.openai.com/v1/chat/completions",
                headers={
                    "Content-Type": "application/json",
                    "Authorization": "Bearer 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",
                },
                json={
                    "model": "gpt-3.5-turbo-1106",
                    "temperature": 0.3,
                    "messages": [
                        {"role": "system", "content": "You are a helpful, professional information search expert."},
                        {"role": "user", "content": related_topic},
                    ],
                },
            )
        response_json = json.loads(response.content)
        return response_json


def generate_summary_service(summary):
        response = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers={
                "Content-Type": "application/json",
                "Authorization": "Bearer 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",
            },
            json={
                "model": "gpt-3.5-turbo-1106",
                "temperature": 0.3,
                "messages": [
                    {"role": "system", "content": "You are a helpful, professional information search expert."},
                    {"role": "user", "content": f"Generate an objective and rigorous summary of all the information in {summary} without including personal pronouns."},
                ],
            },
        )
        response_json = json.loads(response.content)
        return response_json


# databaseService.py
from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(50), nullable=False)
    notes = db.relationship('Note', backref='author', lazy=True)
    user_information_history = []

class Note(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

def before_first_request_service():
    db.create_all()

def gain_user_note_service(user_name):
    user = User.query.filter_by(username=user_name).first()
    user_notes = Note.query.filter_by(author=user).all()

    return user_notes


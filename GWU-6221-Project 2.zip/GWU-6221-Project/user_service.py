class UserNote:
    def __init__(self):
        self.user_input = ""
        self.responses = []
